/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'kipqzmgjqwijpulxctfs.supabase.co',
        pathname: '/**',
      },
      {
        protocol: 'http',
        hostname: 'localhost',
      },
      {
        protocol: 'https',
        hostname: '*.netlify.app',
      },
      {
        protocol: 'https',
        hostname: '*.windsurf.build',
      },
    ],
    unoptimized: true, // Set to true for Netlify deployment
  },
  // Output as a static site for Netlify
  output: 'export',
  // Ensure trailing slashes are handled correctly
  trailingSlash: true,
  // Disable server-side features that aren't compatible with static export
  experimental: {
    // Enable static export for app directory
    appDir: true,
  },
  // Generate a 404 page
  async generateStaticParams() {
    return [
      { slug: '404' },
    ];
  },
}

module.exports = nextConfig
